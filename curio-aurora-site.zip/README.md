# CuriO — PWA assets (icons, maskable icons, screenshots, manifest)

Drop all the PNGs and `manifest.json` into your site **root** (the same folder that
serves `index.html`), then redeploy to Netlify.

## Files
| File | Purpose | In manifest as |
|---|---|---|
| `icon-192.png`, `icon-512.png` | standard icons | `"purpose": "any"` |
| `icon-192-maskable.png`, `icon-512-maskable.png` | adaptive icons (safe-zone padded, full-bleed) | `"purpose": "maskable"` |
| `screenshot-narrow-1.png`, `screenshot-narrow-2.png` | phone install UI (1080×1920) | `"form_factor": "narrow"` |
| `screenshot-wide-1.png` | desktop install UI (1920×1080) | `"form_factor": "wide"` |
| `manifest.json` | web app manifest | — |

## Add these to your <head> (if not already present)
```html
<link rel="manifest" href="/manifest.json" />
<meta name="theme-color" content="#f1e7d2" />
<link rel="apple-touch-icon" href="/icon-192.png" />
```
(Your Apple/mobile web-app meta tags are already in place.)

## Why two icon sets
- **any** — used by platforms that show the icon as-is (older Android, desktop, iOS).
  These have transparent rounded corners so they look right unmasked.
- **maskable** — Android adaptive icons. The launcher crops them to a circle / squircle,
  so the artwork is full-bleed and the mark sits inside the central 80% "safe zone"
  and never gets clipped. Test it at https://maskable.app/editor

## Verify before submitting
1. Open the site → DevTools → **Application → Manifest**. Confirm no errors, both icon
   purposes resolve, and all three screenshots load.
2. Run **Lighthouse → PWA** for an installability check.
3. The `screenshots` array drives Android's richer "install app" dialog. For the actual
   **Play Store listing** (if you wrap with Bubblewrap/PWABuilder into a TWA), Google
   still wants real device captures at the store's required sizes — these manifest
   screenshots are styled to match your app but are not a substitute for store-listing
   screenshots.

## Regenerate with your own logo
`make_icons.py` draws the CuriO sun/crescent mark from scratch. To use your real artwork,
replace the `draw_mark()` body with a paste of your logo PNG (keep it within ~58% of the
canvas for the maskable variant), then re-run `python3 make_icons.py`.
