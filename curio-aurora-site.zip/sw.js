/* CuriO — The Daybook · service worker
   Notifications only — intentionally NO fetch/caching handler, so every deploy is always served fresh. */

self.addEventListener('install', function(){ self.skipWaiting(); });
self.addEventListener('activate', function(e){ e.waitUntil(self.clients.claim()); });

function curioDailyNote(){
  return self.registration.showNotification('CuriO \u2014 The Daybook', {
    body: 'Today\u2019s page is ready \u2014 a quiet moment of wonder awaits. \u2726',
    icon: 'icon-192.png?v=2',
    badge: 'favicon-32.png?v=2',
    tag: 'curio-daily',
    renotify: true
  });
}

/* fires roughly once a day on installed Chromium / your Play (TWA) build */
self.addEventListener('periodicsync', function(e){
  if(e.tag === 'curio-daily'){ e.waitUntil(curioDailyNote()); }
});

/* tap the notification -> focus or open the app */
self.addEventListener('notificationclick', function(e){
  e.notification.close();
  e.waitUntil(
    self.clients.matchAll({ type:'window', includeUncontrolled:true }).then(function(list){
      for(var i=0;i<list.length;i++){ if('focus' in list[i]) return list[i].focus(); }
      if(self.clients.openWindow) return self.clients.openWindow('./');
    })
  );
});
